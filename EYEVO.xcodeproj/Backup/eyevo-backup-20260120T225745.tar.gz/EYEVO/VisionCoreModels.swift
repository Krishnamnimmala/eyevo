//
//  VisionCoreModels.swift
//  EYEVO
//
//  Created by Krishnam Nimmala on 1/15/26.
//

import Foundation

// NOTE: Optotype is defined in Optotype.swift - remove duplicate declaration here to avoid
// ambiguous / redeclaration issues when compiling the project.

// Minimal AdaptiveAlgorithm protocol used by ViewModel/Engine
protocol AdaptiveAlgorithm {
    func start(session: VisionTestSession)
    func update(session: VisionTestSession, correct: Bool, rtMs: Int)
    func nextSize(session: VisionTestSession) -> Double
    func initializeFromSession(session: VisionTestSession)
    func diagnosticConfidence(session: VisionTestSession) -> Double
}

extension AdaptiveAlgorithm {
    func initializeFromSession(session: VisionTestSession) {}
    func diagnosticConfidence(session: VisionTestSession) -> Double { return session.confidence }
}

// MARK: - UI Phase (ViewModel & SwiftUI only)

enum VisionTestPhase: Equatable {
    case preparing
    case running
    case completed
}

enum ResponseDirection: String, CaseIterable {
    case up, down, left, right
}


// MARK: - Engine Phase (Internal state machine)

enum TestPhase: Equatable {
    case gatekeeper
    case tumblingE
    case sloan10
    case completed
}

struct Stimulus {
    let phase: TestPhase
    let optotype: Optotype
    let symbol: String
    let expectedAnswer: ResponseDirection
    let sizeLogMAR: Double
}

struct TestOutcome {
    let estimatedLogMAR: Double?
    let confidence: Double?
    let isValid: Bool
    let passed: Bool
}
