//
//  OptotypeView.swift
//  EYEVO
//
//  Created by Krishnam Nimmala on 1/15/26.
//

import SwiftUI

struct OptotypeView: View {
    let optotype: Optotype
    let direction: ResponseDirection

    var body: some View {
        GeometryReader { geo in
            // Constrain the optotype to a centered square that fits within the
            // available space. Using the minimum of width/height prevents the
            // tumbling E from growing arbitrarily large when the parent gives
            // it unlimited space.
            let size = min(geo.size.width, geo.size.height)

            ZStack {
                Color.clear

                if case .tumblingE = optotype {
                    TumblingEView()
                        .frame(width: size, height: size)
                        .foregroundColor(.white)
                        .rotationEffect(rotationAngle)
                        .onAppear {
                            print("[OptotypeView] appeared — optotype=\(optotype) direction=\(direction)")
                        }
                } else {
                    // Fallback: show simple placeholder letter (shouldn't be used yet)
                    Text("?")
                        .font(.system(size: 120, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                }
            }
            // center the ZStack inside the geometry reader
            .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
        }
        // prefer a square aspect ratio when the view is used without an explicit frame
        .aspectRatio(1, contentMode: .fit)
    }

    private var rotationAngle: Angle {
        switch direction {
        case .up: return .degrees(0)
        case .right: return .degrees(90)
        case .down: return .degrees(180)
        case .left: return .degrees(270)
        }
    }

    /// Programmatic tumbling "E" constructed from rectangles. Scales to available size.
    private struct TumblingEView: View {
        var body: some View {
            GeometryReader { g in
                let w = min(g.size.width, g.size.height)
                let h = w
                let thickness = w * 0.18
                let barLength = w * 0.6
                let leftX: CGFloat = (w - (thickness + barLength)) / 2.0

                ZStack {
                    // Vertical stem
                    Rectangle()
                        .frame(width: thickness, height: h * 0.9)
                        .position(x: leftX + thickness / 2.0, y: h / 2.0)

                    // Top bar
                    Rectangle()
                        .frame(width: barLength, height: thickness)
                        .position(x: leftX + thickness + barLength / 2.0, y: h * 0.18)

                    // Middle bar
                    Rectangle()
                        .frame(width: barLength, height: thickness)
                        .position(x: leftX + thickness + barLength / 2.0, y: h / 2.0)

                    // Bottom bar
                    Rectangle()
                        .frame(width: barLength, height: thickness)
                        .position(x: leftX + thickness + barLength / 2.0, y: h * 0.82)
                }
                .frame(width: w, height: h)
            }
        }
    }
}
