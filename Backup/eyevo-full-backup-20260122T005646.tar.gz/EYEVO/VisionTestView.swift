import SwiftUI
import Combine
import AVFoundation

struct VisionTestView: View {

    @StateObject private var viewModel: VisionTestViewModel

    @State private var showOptotype = false
    @State private var showButtons = false
    @State private var buttonsEnabled = false

    @State private var showResult = false
    @State private var finalOutcome: TestOutcome?
    @State private var didPresentResult = false
    @State private var didStart = false

    // Track when the optotype was shown so we can compute response times (milliseconds)
    @State private var optotypeShownAt: Date? = nil

    /// If `useQuest` is nil the view will consult UserDefaults/AppStorage key "useQuest".
    init(useQuest: Bool? = nil) {
        let selected: Bool
        if let explicit = useQuest {
            selected = explicit
        } else {
            selected = UserDefaults.standard.bool(forKey: "useQuest")
        }

        if selected {
            _viewModel = StateObject(wrappedValue: VisionTestViewModel(algorithm: QuestAlgorithm()))
        } else {
            _viewModel = StateObject(wrappedValue: VisionTestViewModel())
        }
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 16) {

                // PREPARING
                if viewModel.phase == .preparing {
                    Text("Prepare for the vision test…")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.85))
                        .padding(.top, 12)
                }

                Spacer()

                // INTERACTIVE (gatekeeper + running)
                if (viewModel.phase == .preparing || viewModel.phase == .running),
                   let stimulus = viewModel.currentStimulus,
                   showOptotype {

                    // Use programmatic tumbling 'E' view which scales and rotates cleanly.
                    // DEBUG: show red outline and label so optotype is obvious on black background.
                    #if DEBUG
                    ZStack {
                        OptotypeView(optotype: stimulus.optotype, direction: stimulus.expectedAnswer)
                            .frame(width: 280, height: 280)

                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.red, lineWidth: 3)
                            .frame(width: 300, height: 300)

                        Text("OPTOTYPE")
                            .foregroundColor(.red)
                            .font(.caption)
                            .offset(y: -180)
                    }
                    #else
                    OptotypeView(optotype: stimulus.optotype, direction: stimulus.expectedAnswer)
                        .frame(width: 220, height: 220)
                        .foregroundColor(.white)
                    #endif

                } else if viewModel.phase == .preparing {
                    Text("Preparing test…")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.70))
                }

                Spacer()

                if (viewModel.phase == .preparing || viewModel.phase == .running) && showButtons {
                    DirectionButtonGrid(
                        enabled: buttonsEnabled,
                        onSelect: handleResponse
                    )
                    .padding(.bottom, 34)
                }


            }
        }
        .onAppear {
            guard !didStart else { return }
            didStart = true

            // Configure audio early so playback is available when optotypes appear
            AudioManager.shared.configureSessionIfNeeded()
            print("[VisionTestView] onAppear — beginTest(), phase=\(viewModel.phase)")

            viewModel.beginTest()
            viewModel.getNextStimulus()
            startTrial()
        }
        .onReceive(viewModel.phasePublisher) { newPhase in
            if newPhase == .running {
                startTrial()
            }

            if newPhase == .completed {
                presentResultIfNeeded()
            }
        }
        .navigationBarBackButtonHidden(true)
        .sheet(isPresented: $showResult) {
            if let outcome = finalOutcome {
                ResultView(outcome: outcome, onRestart: resetTest)
            }
        }
        // Play a click whenever the optotype becomes visible
        .onChange(of: showOptotype) { newValue in
            if newValue {
                print("[VisionTestView] showOptotype == true, stimulus=\(String(describing: viewModel.currentStimulus?.symbol))")
                AudioManager.shared.playSound(named: "click")
                optotypeShownAt = Date()
            } else {
                print("[VisionTestView] showOptotype == false")
                // clear timestamp when optotype hidden
                // (we keep the last timestamp until a response to compute rtMs)
            }
        }

    } // <- close `var body` here

    // MARK: - Trial Loop

    private func startTrial() {
        guard viewModel.phase == .running || viewModel.phase == .preparing else { return }

        print("[VisionTestView] startTrial() — phase=\(viewModel.phase) currentStimulus=\(String(describing: viewModel.currentStimulus?.symbol))")

        showButtons = false
        buttonsEnabled = false
        showOptotype = false

        if viewModel.currentStimulus == nil {
            viewModel.getNextStimulus()
        }

        guard viewModel.currentStimulus != nil else { return }

        showOptotype = true
        print("[VisionTestView] displaying optotype")

        let exposure = Double.random(in: 0.85...1.15)
        DispatchQueue.main.asyncAfter(deadline: .now() + exposure) {
            guard viewModel.phase != .completed else { return }

            showOptotype = false

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                guard viewModel.phase != .completed else { return }
                showButtons = true

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.40) {
                    guard viewModel.phase != .completed else { return }
                    buttonsEnabled = true
                }
            }
        }
    }

    private func handleResponse(_ direction: ResponseDirection) {
        guard buttonsEnabled else { return }

        buttonsEnabled = false
        showButtons = false

        // play a click for immediate feedback
        AudioManager.shared.playSound(named: "click")

        // compute response time (milliseconds). If we don't have a shown timestamp, pass 0.
        let rtMs: Int
        if let shown = optotypeShownAt {
            rtMs = Int(Date().timeIntervalSince(shown) * 1000.0)
        } else {
            rtMs = 0
        }

        viewModel.submitResponse(direction, rtMs: rtMs)

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
            startTrial()
        }
    }

    private func presentResultIfNeeded() {
        guard !didPresentResult else { return }
        didPresentResult = true

        finalOutcome = viewModel.finalizeSession()
        showResult = true
    }

    private func resetTest() {
        showResult = false
        finalOutcome = nil
        didPresentResult = false

        showOptotype = false
        showButtons = false
        buttonsEnabled = false

        viewModel.beginTest()
        viewModel.getNextStimulus()
        startTrial()
    }
    
    //rotation helper (UI-only)
    private func rotation(for direction: ResponseDirection) -> Angle {
        switch direction {
        case .up:    return .degrees(0)
        case .right: return .degrees(90)
        case .down:  return .degrees(180)
        case .left:  return .degrees(270)
        }
    }

}
