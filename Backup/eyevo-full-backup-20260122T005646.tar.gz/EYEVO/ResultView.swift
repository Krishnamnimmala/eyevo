import SwiftUI

struct ResultView: View {

    let outcome: TestOutcome
    let onRestart: () -> Void

    @Environment(\.dismiss) private var dismiss

    private var resultTitle: String {
        outcome.passed ? "VISION SCREEN: PASS" : "VISION SCREEN: REFER"
    
        
    }

    private var resultColor: Color {
        outcome.passed ? .green : .orange
    }

    private var confidence: Double {
        let raw = outcome.confidence ?? 0.0
        return min(max(raw, 0.0), 1.0)
    }

    private var resultExplanation: String {
        outcome.passed
        ? "Your screening responses were consistent with expected vision thresholds."
        : "This screening suggests a follow-up eye exam may be helpful."
    }

    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 12) {
                // Cap the card height to 60% of available height or 560pt max
                let cardMaxHeight = min(geo.size.height * 0.6, CGFloat(560))

                ScrollView(.vertical, showsIndicators: true) {
                    VStack(spacing: 18) {
                        Text("Vision Screening Result")
                            .font(.title3)
                            .fontWeight(.semibold)

                        // PASS / REFER
                        Text(resultTitle)
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(resultColor)
                            .multilineTextAlignment(.center)
                            .lineLimit(2)
                            .minimumScaleFactor(0.6)
                            .accessibilityLabel(
                                outcome.passed
                                ? "Vision screening passed"
                                : "Vision screening recommends follow-up"
                            )

                        Text(resultExplanation)
                            .font(.body)
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)

                        // Confidence Indicator
                        VStack(spacing: 6) {
                            Text("Confidence")
                                .font(.subheadline)
                                .foregroundColor(.secondary)

                            ProgressView(value: confidence)
                                .tint(resultColor)
                                .accessibilityLabel("Confidence level")
                                .accessibilityValue("\(Int(confidence * 100)) percent")


                            Text("\(Int(confidence * 100))%")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }

                        // Acuity
                        VStack(spacing: 8) {
                            Text("Estimated Visual Acuity")
                                .font(.headline)

                            if let logMAR = outcome.estimatedLogMAR {
                                Text(String(format: "logMAR %.2f", logMAR))
                                    .font(.title3)
                                    .minimumScaleFactor(0.7)
                                    .lineLimit(1)
                            } else {
                                Text(resultTitle)
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(resultColor)
                                    .multilineTextAlignment(.center)
                                    .lineLimit(2)
                                    .minimumScaleFactor(0.6)
                            }
                        }

                        // FDA-safe disclaimer — allow the text to wrap fully
                        Text(disclaimerText)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .opacity(0.85)
                            .padding(.horizontal)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(.systemBackground))
                            .shadow(radius: 6)
                    )
                    .padding(.horizontal)
                    .padding(.top)
                }
                .frame(maxWidth: .infinity)
                .frame(height: cardMaxHeight)

                // Action buttons stay below and are always visible
                VStack(spacing: 12) {
                    Button("Retake Screening") {
                        onRestart()
                    }
                    .buttonStyle(.borderedProminent)

                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.secondary)
                }
                .padding(.bottom, 12)
            }
            .padding()
            .dynamicTypeSize(.small ... .xxLarge)
        }
    }

    private var disclaimerText: String {
        """
        This vision screening is not a medical diagnosis.
        Results are for informational purposes only and should not be used
        to diagnose or treat any eye condition.
        Consult a qualified eye care professional for a comprehensive exam.
        """
    }
}
